
 Required external libraries and their applicable licenses
===========================================================

Library                 License
-------------------------------------------
antlr*                  antlr.txt (BSD)
avalon-framework*       apache.txt
batik-all*              apache.txt
bsh*                    sun.txt / gnu-lgpl-3.0.txt
byteseek*               byteseek.txt (BSD)
commons*                apache.txt
DCVE*                   
docuteam*               docuteam.txt
dom4j*                  dom4j.txt
droid*                  droid.txt (BSD)
fop*                    apache.txt
gson*                   GoogleGson.txt
icepdf*                 apache.txt, CCITTFax_license.txt, JBIG2_license.txt, MPL-1.1.txt
jai*                    jai.txt
jaxen*                  jaxen.txt
jdom*                   jdom.txt
jhove*                  jhove.txt (LGPL >= v2.1)
JimiPro*                sun.txt
jodconverter*           jodconverter.txt
juh*                    sun.txt
jurt*                   sun.txt
log4j*                  apache.txt
mail*                   sun.txt (CDDL 1.0)
metadata-extractor*     apache.txt
mysql-connector*        gnu-gpl-2.0.txt
poi*                    apache.txt
ridl*                   sun.txt
saxon*                  mozilla-2.0.txt
*slf4j*                 mit.txt
soap*                   apache.txt
swingx*                 sun.txt (CDDL 1.0)
truezip*                apache.txt
unoil*                  sun.txt
xerces*                 apache.txt
xmlgraphics-common*     apache.txt
xmpcore*                adobe.txt (BSD)
xstream*                xstream.txt

Some icons by Yusuke Kamiyamane (http://p.yusukekamiyamane.com)
                        creative-commons-3.0.txt

Some icons by Axialis Software (http://www.axialis.com)
                        creative-commons-2.5.txt
-------------------------------------------
