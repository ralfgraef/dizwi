#!/bin/sh
#		Shell script template to run docuteam packer under OS X

export	LC_CTYPE="UTF-8"

cd		"$(dirname "$0")/docuteam packer.app/Contents/docuteam packer"
java	-Xms512M -Xmx1024M -Xdock:icon=resources/images/DocuteamPacker.ico -Xdock:name="docuteam packer" -jar DocuteamPacker.jar &

#		Additional optional parameters:

#		-configDir="/Users/denis/Documents/Java/Workspace/Docupack/config"
#		-open="/Users/denis/Documents/Java/Workspace/Docupack/files/DifferentFileTypes"
#		-help
