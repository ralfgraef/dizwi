#!/bin/sh
#		Shell script template to run docuteam packer under Linux

export	LC_CTYPE="UTF-8"

cd		"$(dirname "$0")/docuteam packer.app/Contents/docuteam packer"
java	-Xms512M -Xmx1024M -jar DocuteamPacker.jar &

#		Additional optional parameters:

#		-configDir="/Users/denis/Documents/Java/Workspace/Docupack/config"
#		-open="/Users/denis/Documents/Java/Workspace/Docupack/files/DifferentFileTypes"
#		-help
